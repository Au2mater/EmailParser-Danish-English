# EmailParser-Danish-English
Parse email text to structured python dictionaries or json. 

Auto detect and extract the following:
 - Sender
 - Date
 - Recpients
 - Greeting
 - Email body
 - Signature
 - Nested Forwarded mail
 - Nested reply history
